Placeholder directory — see README.md for why this project doesn't ship binary 3D model assets, and how to drop your own .glb/.gltf character or prop models in here.
