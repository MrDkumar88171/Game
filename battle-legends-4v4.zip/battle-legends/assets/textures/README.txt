Placeholder directory — drop texture image files (.jpg/.png/.ktx2) here if you extend map.js / weapon.js to use texture maps instead of flat materials.
